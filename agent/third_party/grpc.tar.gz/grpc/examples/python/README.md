[This code's documentation lives on the grpc.io site.](https://grpc.io/docs/languages/python/quickstart)
