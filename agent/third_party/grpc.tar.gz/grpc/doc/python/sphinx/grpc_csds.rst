gRPC CSDS
=========

What is gRPC CSDS?
---------------------------------------------

In short, it's a xDS configuration dump protocol.

Design Document `gRPC CSDS <https://github.com/grpc/proposal/blob/master/A40-csds-support.md>`_

Module Contents
---------------

.. automodule:: grpc_csds
